import 'package:flutter_test/flutter_test.dart';
import 'package:th3/main.dart';

void main() {
  testWidgets('Weather App smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const MyApp());
    await tester.pumpAndSettle();

    // Verify that title and section headers exist
    expect(find.textContaining('Dự báo thời tiết'), findsOneWidget);
    expect(find.text('Thành phố nổi bật'), findsOneWidget);
  });
}
