import 'package:flutter/material.dart';
import '../models/weather_data.dart';
import '../services/weather_service.dart';
import '../widgets/weather_icon_widget.dart';
import 'detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  String studentId = '21110000'; // Replaceable student ID (MSSV)

  // Master list of Vietnamese & World city suggestions for autocomplete
  final List<String> _allCitySuggestions = [
    'Hà Nội',
    'Thành phố Hồ Chí Minh',
    'Hải Phòng',
    'Cần Thơ',
    'Đà Nẵng',
    'Huế',
    'Nha Trang',
    'Vũng Tàu',
    'Quy Nhơn',
    'Tokyo',
    'Paris',
    'Thành phố New York',
    'London',
    'Seoul',
    'Bangkok',
    'Singapore',
  ];

  List<String> _filteredSuggestions = [];
  bool _showSuggestions = false;

  // List of featured cities shown on main screen
  final List<String> _featuredCityNames = [
    'Hà Nội',
    'Thành phố Hồ Chí Minh',
    'Đà Nẵng',
    'Tokyo',
    'Paris',
    'Thành phố New York',
  ];

  Map<String, WeatherData> _featuredWeatherData = {};
  bool _isLoadingFeatured = true;

  // Search state
  WeatherData? _searchedWeather;
  bool _isSearching = false;
  String? _searchError;

  @override
  void initState() {
    super.initState();
    _loadFeaturedWeather();

    _searchController.addListener(_onSearchQueryChanged);
    _searchFocusNode.addListener(() {
      if (!_searchFocusNode.hasFocus) {
        setState(() {
          _showSuggestions = false;
        });
      }
    });
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchQueryChanged);
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  void _onSearchQueryChanged() {
    final query = _searchController.text.trim().toLowerCase();
    if (query.isNotEmpty) {
      final matches = _allCitySuggestions.where((city) {
        return city.toLowerCase().contains(query) ||
            _stripAccents(city.toLowerCase()).contains(_stripAccents(query));
      }).toList();

      setState(() {
        _filteredSuggestions = matches;
        _showSuggestions = matches.isNotEmpty;
      });
    } else {
      setState(() {
        _filteredSuggestions = [];
        _showSuggestions = false;
        _searchedWeather = null;
      });
    }
  }

  String _stripAccents(String str) {
    var withAccents = 'àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ';
    var withoutAccents = 'aaaaaaaaaaaaaaaaaeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyyd';
    var result = str;
    for (int i = 0; i < withAccents.length; i++) {
      result = result.replaceAll(withAccents[i], withoutAccents[i]);
    }
    return result;
  }

  Future<void> _loadFeaturedWeather() async {
    setState(() {
      _isLoadingFeatured = true;
    });

    Map<String, WeatherData> dataMap = {};
    for (String city in _featuredCityNames) {
      final weather = await WeatherService.fetchWeather(city);
      dataMap[city] = weather;
    }

    if (mounted) {
      setState(() {
        _featuredWeatherData = dataMap;
        _isLoadingFeatured = false;
      });
    }
  }

  Future<void> _performSearch(String cityName) async {
    if (cityName.trim().isEmpty) return;

    FocusScope.of(context).unfocus();
    setState(() {
      _showSuggestions = false;
      _isSearching = true;
      _searchError = null;
    });

    try {
      final weather = await WeatherService.fetchWeather(cityName.trim());
      if (mounted) {
        setState(() {
          _searchedWeather = weather;
          _isSearching = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _searchError = 'Không tìm thấy dữ liệu thời tiết cho "$cityName"';
          _isSearching = false;
        });
      }
    }
  }

  void _showApiKeyDialog() {
    final keyController = TextEditingController(text: WeatherService.apiKey);
    final mssvController = TextEditingController(text: studentId);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Cấu hình ứng dụng'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: mssvController,
                decoration: const InputDecoration(
                  labelText: 'MSSV',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: keyController,
                decoration: const InputDecoration(
                  labelText: 'API Key (OpenWeatherMap)',
                  border: OutlineInputBorder(),
                  hintText: 'Nhập API key...',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Hủy'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  studentId = mssvController.text.trim();
                  WeatherService.apiKey = keyController.text.trim();
                });
                Navigator.pop(context);
                _loadFeaturedWeather();
              },
              child: const Text('Lưu'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FA),
      appBar: AppBar(
        title: Text(
          '$studentId - Dự báo thời tiết',
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.grey),
            onPressed: _showApiKeyDialog,
            tooltip: 'Cài đặt API Key & MSSV',
          ),
        ],
      ),
      body: Stack(
        children: [
          // Main scrollable content
          RefreshIndicator(
            onRefresh: _loadFeaturedWeather,
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Search Bar
                  _buildSearchBar(),

                  const SizedBox(height: 20),

                  // Searched Weather Card / Inline View (Page 3 matching)
                  if (_isSearching)
                    const Padding(
                      padding: EdgeInsets.all(24.0),
                      child: Center(child: CircularProgressIndicator()),
                    )
                  else if (_searchError != null)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12.0),
                      child: Text(
                        _searchError!,
                        style: const TextStyle(color: Colors.red, fontSize: 14),
                      ),
                    )
                  else if (_searchedWeather != null) ...[
                    _buildSearchedWeatherView(_searchedWeather!),
                    const SizedBox(height: 24),
                  ],

                  // "Thành phố nổi bật" Section (Page 1 matching)
                  const Text(
                    'Thành phố nổi bật',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),

                  const SizedBox(height: 12),

                  if (_isLoadingFeatured)
                    const Padding(
                      padding: EdgeInsets.all(32.0),
                      child: Center(child: CircularProgressIndicator()),
                    )
                  else
                    ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _featuredCityNames.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final cityName = _featuredCityNames[index];
                        final weather = _featuredWeatherData[cityName];
                        if (weather == null) return const SizedBox.shrink();
                        return _buildFeaturedCityTile(weather);
                      },
                    ),

                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),

          // Autocomplete Dropdown Overlay (Page 2 matching)
          if (_showSuggestions && _filteredSuggestions.isNotEmpty)
            Positioned(
              top: 72,
              left: 16,
              right: 16,
              child: Material(
                elevation: 6,
                borderRadius: BorderRadius.circular(12),
                color: Colors.grey.shade200.withValues(alpha: 0.95),
                child: Container(
                  constraints: const BoxConstraints(maxHeight: 200),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEFEFEF),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: ListView.separated(
                    shrinkWrap: true,
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    itemCount: _filteredSuggestions.length,
                    separatorBuilder: (_, __) => Divider(
                      height: 1,
                      color: Colors.grey.shade300,
                    ),
                    itemBuilder: (context, index) {
                      final suggestion = _filteredSuggestions[index];
                      return ListTile(
                        dense: true,
                        title: Text(
                          suggestion,
                          style: const TextStyle(
                            fontSize: 14,
                            color: Colors.black87,
                          ),
                        ),
                        onTap: () {
                          _searchController.text = suggestion;
                          _performSearch(suggestion);
                        },
                      );
                    },
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // Search Bar Widget
  Widget _buildSearchBar() {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          const SizedBox(width: 14),
          Expanded(
            child: TextField(
              controller: _searchController,
              focusNode: _searchFocusNode,
              onSubmitted: (value) => _performSearch(value),
              decoration: InputDecoration(
                hintText: 'Nhập tên thành phố (vd: Hà Nội)...',
                hintStyle: TextStyle(
                  color: Colors.grey.shade500,
                  fontSize: 14,
                ),
                border: InputBorder.none,
                isDense: true,
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, size: 20, color: Colors.grey),
                        onPressed: () {
                          _searchController.clear();
                        },
                      )
                    : null,
              ),
            ),
          ),
          const SizedBox(width: 6),
          // Blue search button matching image
          InkWell(
            onTap: () => _performSearch(_searchController.text),
            borderRadius: const BorderRadius.only(
              topRight: Radius.circular(13),
              bottomRight: Radius.circular(13),
            ),
            child: Container(
              width: 50,
              height: 52,
              decoration: const BoxDecoration(
                color: Color(0xFF2196F3),
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(13),
                  bottomRight: Radius.circular(13),
                ),
              ),
              child: const Icon(
                Icons.search,
                color: Colors.white,
                size: 24,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Searched Weather Card matching Page 3 of PDF
  Widget _buildSearchedWeatherView(WeatherData weather) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DetailScreen(weatherData: weather),
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              weather.cityName,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 18),
            WeatherIconWidget(
              description: weather.description,
              iconCode: weather.iconCode,
              size: 52,
            ),
            const SizedBox(height: 18),
            Text(
              '${weather.temp.toStringAsFixed(1)}°C',
              style: const TextStyle(
                fontSize: 38,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              weather.description.toUpperCase(),
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Colors.grey,
                letterSpacing: 1.1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Featured City Item Tile matching Page 1 of PDF
  Widget _buildFeaturedCityTile(WeatherData weather) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DetailScreen(weatherData: weather),
          ),
        );
      },
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
          color: const Color(0xFFF1F3F5),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            // Icon
            WeatherIconWidget(
              description: weather.description,
              iconCode: weather.iconCode,
              size: 26,
            ),
            const SizedBox(width: 16),

            // City name & description
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    weather.cityName,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    weather.description,
                    style: const TextStyle(
                      fontSize: 13,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),

            // Temperature in bold blue text
            Text(
              '${weather.temp.toStringAsFixed(1)}°C',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF2196F3),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
