import 'package:flutter/material.dart';

class WeatherIconWidget extends StatelessWidget {
  final String description;
  final String iconCode;
  final double size;

  const WeatherIconWidget({
    super.key,
    required this.description,
    required this.iconCode,
    this.size = 28.0,
  });

  @override
  Widget build(BuildContext context) {
    final desc = description.toLowerCase();

    // Determine color and style matching the PDF assignment screenshots
    Color primaryColor;
    Widget iconContent;

    if (desc.contains('quang') || desc.contains('nắng') || iconCode == '01d' || iconCode == '01n') {
      // Clear/Sunny -> Orange circle
      primaryColor = const Color(0xFFE05C3E);
      iconContent = Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: primaryColor,
          shape: BoxShape.circle,
        ),
      );
    } else if (desc.contains('thưa') || iconCode == '02d' || iconCode == '02n') {
      // Few clouds -> Half oval/semicircle or icon
      primaryColor = const Color(0xFFE05C3E);
      iconContent = Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: primaryColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(size),
            topRight: Radius.circular(size / 2),
            bottomLeft: Radius.circular(size / 2),
            bottomRight: Radius.circular(size),
          ),
        ),
      );
    } else if (desc.contains('cụm') || desc.contains('nhiều mây') || iconCode.contains('03') || iconCode.contains('04')) {
      // Scattered/broken clouds -> Dark grey oval / cloud shape
      primaryColor = const Color(0xFF4A4A4A);
      iconContent = Transform.rotate(
        angle: -0.5,
        child: Container(
          width: size,
          height: size * 0.65,
          decoration: BoxDecoration(
            color: primaryColor,
            borderRadius: BorderRadius.circular(size / 2),
          ),
        ),
      );
    } else {
      // General weather -> Dark grey circle
      primaryColor = const Color(0xFF555555);
      iconContent = Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: primaryColor,
          shape: BoxShape.circle,
        ),
      );
    }

    return SizedBox(
      width: size + 8,
      height: size + 8,
      child: Center(child: iconContent),
    );
  }
}
