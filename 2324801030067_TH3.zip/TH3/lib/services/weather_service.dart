import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/weather_data.dart';

class WeatherService {
  // Default OpenWeatherMap API key (can be replaced by user in app settings)
  static String apiKey = 'bd573299f1d00c3a216f4ad930514a38'; 

  static Future<WeatherData> fetchWeather(String cityName) async {
    final formattedCity = _cleanCityName(cityName);
    final url = Uri.parse(
      'https://api.openweathermap.org/data/2.5/weather?q=${Uri.encodeComponent(formattedCity)}&units=metric&lang=vi&appid=$apiKey',
    );

    try {
      final response = await http.get(url).timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return WeatherData.fromJson(data);
      } else {
        // Return matching mock/fallback data if API call returns error or key is expired
        return WeatherData.getFallbackForCity(cityName);
      }
    } catch (e) {
      // Fallback on network exception or timeout
      return WeatherData.getFallbackForCity(cityName);
    }
  }

  static String _cleanCityName(String city) {
    if (city.trim().toLowerCase() == 'hà nội' || city.trim().toLowerCase() == 'ha noi') {
      return 'Hanoi';
    }
    if (city.trim().toLowerCase() == 'thành phố hồ chí minh' ||
        city.trim().toLowerCase() == 'hồ chí minh' ||
        city.trim().toLowerCase() == 'ho chi minh') {
      return 'Ho Chi Minh City';
    }
    if (city.trim().toLowerCase() == 'đà nẵng' || city.trim().toLowerCase() == 'da nang') {
      return 'Da Nang';
    }
    if (city.trim().toLowerCase() == 'thành phố new york' || city.trim().toLowerCase() == 'new york') {
      return 'New York';
    }
    return city;
  }
}
