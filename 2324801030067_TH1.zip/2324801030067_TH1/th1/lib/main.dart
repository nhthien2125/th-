import 'package:flutter/material.dart';

void main() {
  runApp(const CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Máy tính bỏ túi',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF303030),
      ),
      home: const CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _display = '0';
  double? _firstOperand;
  String? _operator;
  bool _shouldResetDisplay = false;

  void _onDigitPressed(String digit) {
    setState(() {
      if (_display == 'Lỗi' || _shouldResetDisplay) {
        _display = digit;
        _shouldResetDisplay = false;
      } else {
        if (_display == '0') {
          _display = digit;
        } else {
          _display += digit;
        }
      }
    });
  }

  void _onCommaPressed() {
    setState(() {
      if (_display == 'Lỗi' || _shouldResetDisplay) {
        _display = '0,';
        _shouldResetDisplay = false;
      } else if (!_display.contains(',')) {
        _display += ',';
      }
    });
  }

  void _onClearPressed() {
    setState(() {
      _display = '0';
      _firstOperand = null;
      _operator = null;
      _shouldResetDisplay = false;
    });
  }

  void _onBackspacePressed() {
    setState(() {
      if (_display == 'Lỗi' || _shouldResetDisplay) {
        _display = '0';
        _shouldResetDisplay = false;
        return;
      }
      if (_display.length > 1) {
        _display = _display.substring(0, _display.length - 1);
        if (_display == '-') {
          _display = '0';
        }
      } else {
        _display = '0';
      }
    });
  }

  void _onOperatorPressed(String op) {
    setState(() {
      if (_display == 'Lỗi') return;

      double currentValue = _parseDisplay(_display);

      if (_firstOperand != null && _operator != null && !_shouldResetDisplay) {
        double? result = _calculate(_firstOperand!, currentValue, _operator!);
        if (result == null) {
          _display = 'Lỗi';
          _firstOperand = null;
          _operator = null;
          _shouldResetDisplay = true;
          return;
        } else {
          _firstOperand = result;
          _display = _formatResult(result);
        }
      } else {
        _firstOperand = currentValue;
      }

      _operator = op;
      _shouldResetDisplay = true;
    });
  }

  void _onEqualsPressed() {
    setState(() {
      if (_display == 'Lỗi' || _firstOperand == null || _operator == null) {
        return;
      }

      double secondOperand = _parseDisplay(_display);
      double? result = _calculate(_firstOperand!, secondOperand, _operator!);

      if (result == null) {
        _display = 'Lỗi';
      } else {
        _display = _formatResult(result);
      }

      _firstOperand = null;
      _operator = null;
      _shouldResetDisplay = true;
    });
  }

  double _parseDisplay(String text) {
    String normalized = text.replaceAll(',', '.');
    return double.tryParse(normalized) ?? 0.0;
  }

  double? _calculate(double num1, double num2, String op) {
    switch (op) {
      case '+':
        return num1 + num2;
      case '-':
        return num1 - num2;
      case '×':
        return num1 * num2;
      case '÷':
        if (num2 == 0) return null; // Division by zero
        return num1 / num2;
      default:
        return num2;
    }
  }

  String _formatResult(double value) {
    if (value.isNaN || value.isInfinite) return 'Lỗi';

    // If it's a whole number
    if (value == value.roundToDouble() && value.abs() < 1e12) {
      return value.toInt().toString();
    }

    String res = value.toStringAsFixed(8);
    // Trim trailing zeros
    if (res.contains('.')) {
      res = res.replaceAll(RegExp(r'0+$'), '');
      res = res.replaceAll(RegExp(r'\.$'), '');
    }
    return res.replaceAll('.', ',');
  }

  Widget _buildButton({
    required Widget child,
    required VoidCallback onPressed,
    Color backgroundColor = const Color(0xFF424242),
    Color textColor = Colors.white,
    int flex = 1,
  }) {
    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.all(6.0),
        child: SizedBox(
          height: 72,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: backgroundColor,
              foregroundColor: textColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 0,
              padding: EdgeInsets.zero,
            ),
            onPressed: onPressed,
            child: child,
          ),
        ),
      ),
    );
  }

  Widget _buildTextButton(
    String text,
    VoidCallback onPressed, {
    Color backgroundColor = const Color(0xFF424242),
    Color textColor = Colors.white,
    int flex = 1,
  }) {
    return _buildButton(
      flex: flex,
      backgroundColor: backgroundColor,
      textColor: textColor,
      onPressed: onPressed,
      child: Text(
        text,
        style: TextStyle(
          fontSize: 26,
          fontWeight: FontWeight.w400,
          color: textColor,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF303030),
      body: SafeArea(
        child: Column(
          children: [
            // Student ID / Name Header at top display
            const SizedBox(height: 20),
            const Text(
              '2324801030067 - Nguyen Hoang Thien',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 16,
                fontWeight: FontWeight.w400,
              ),
            ),

            // Flexible Display Area
            Expanded(
              child: Container(
                alignment: Alignment.bottomRight,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 24,
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  reverse: true,
                  child: Text(
                    _display,
                    style: const TextStyle(
                      fontSize: 64,
                      fontWeight: FontWeight.w300,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),

            // Keypad Grid Layout
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              child: Column(
                children: [
                  // Row 1: [0] [C] [,] [⌫]
                  Row(
                    children: [
                      _buildTextButton('0', () => _onDigitPressed('0')),
                      _buildTextButton('C', _onClearPressed),
                      _buildTextButton(',', _onCommaPressed),
                      _buildButton(
                        onPressed: _onBackspacePressed,
                        child: const Icon(
                          Icons.backspace_outlined,
                          size: 24,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),

                  // Row 2: [7] [8] [9] [÷]
                  Row(
                    children: [
                      _buildTextButton('7', () => _onDigitPressed('7')),
                      _buildTextButton('8', () => _onDigitPressed('8')),
                      _buildTextButton('9', () => _onDigitPressed('9')),
                      _buildTextButton('÷', () => _onOperatorPressed('÷')),
                    ],
                  ),

                  // Row 3: [4] [5] [6] [×]
                  Row(
                    children: [
                      _buildTextButton('4', () => _onDigitPressed('4')),
                      _buildTextButton('5', () => _onDigitPressed('5')),
                      _buildTextButton('6', () => _onDigitPressed('6')),
                      _buildTextButton('×', () => _onOperatorPressed('×')),
                    ],
                  ),

                  // Row 4: [1] [2] [3] [-]
                  Row(
                    children: [
                      _buildTextButton('1', () => _onDigitPressed('1')),
                      _buildTextButton('2', () => _onDigitPressed('2')),
                      _buildTextButton('3', () => _onDigitPressed('3')),
                      _buildTextButton('-', () => _onOperatorPressed('-')),
                    ],
                  ),

                  // Row 5: [ = (spans 3) ] [+]
                  Row(
                    children: [
                      _buildTextButton(
                        '=',
                        _onEqualsPressed,
                        backgroundColor: const Color(0xFF81D4FA), // Light blue
                        textColor: const Color(0xFF212121), // Dark text
                        flex: 3,
                      ),
                      _buildTextButton('+', () => _onOperatorPressed('+')),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
