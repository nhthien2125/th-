import 'package:flutter_test/flutter_test.dart';
import 'package:th1/main.dart';

void main() {
  testWidgets('Calculator app smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const CalculatorApp());

    // Verify that initial display shows '0'
    expect(find.text('0'), findsWidgets);

    // Tap '7' and trigger a frame
    await tester.tap(find.text('7'));
    await tester.pump();

    // Verify '7' appears
    expect(find.text('7'), findsWidgets);
  });
}
