import 'dart:math' as math;
import 'package:flutter/material.dart';

void main() {
  runApp(const CalculatorApp());
}

class HistoryItem {
  final String expression;
  final String result;

  HistoryItem({required this.expression, required this.result});
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Máy tính nâng cao',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF1E1E1E),
      ),
      home: const CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _display = '0';
  String _expression = '';
  double? _firstOperand;
  String? _operator;
  bool _shouldResetDisplay = false;

  // Memory
  double _memory = 0.0;
  bool _hasMemory = false;

  // Calculation History
  final List<HistoryItem> _history = [];

  void _onDigitPressed(String digit) {
    setState(() {
      if (_display == 'Lỗi' || _shouldResetDisplay) {
        _display = digit;
        _shouldResetDisplay = false;
      } else {
        if (_display == '0') {
          _display = digit;
        } else if (_display == '-0') {
          _display = '-$digit';
        } else {
          _display += digit;
        }
      }
    });
  }

  void _onCommaPressed() {
    setState(() {
      if (_display == 'Lỗi' || _shouldResetDisplay) {
        _display = '0,';
        _shouldResetDisplay = false;
      } else if (!_display.contains(',')) {
        _display += ',';
      }
    });
  }

  void _onClearPressed() {
    setState(() {
      _display = '0';
      _expression = '';
      _firstOperand = null;
      _operator = null;
      _shouldResetDisplay = false;
    });
  }

  void _onClearEntryPressed() {
    setState(() {
      _display = '0';
      _shouldResetDisplay = false;
    });
  }

  void _onBackspacePressed() {
    setState(() {
      if (_display == 'Lỗi' || _shouldResetDisplay) {
        _display = '0';
        _shouldResetDisplay = false;
        return;
      }
      if (_display.length > 1) {
        _display = _display.substring(0, _display.length - 1);
        if (_display == '-' || _display == '-0') {
          _display = '0';
        }
      } else {
        _display = '0';
      }
    });
  }

  void _onNegatePressed() {
    setState(() {
      if (_display == 'Lỗi') return;
      if (_display.startsWith('-')) {
        _display = _display.substring(1);
      } else if (_display != '0') {
        _display = '-$_display';
      }
    });
  }

  void _onOperatorPressed(String op) {
    setState(() {
      if (_display == 'Lỗi') return;

      double currentValue = _parseDisplay(_display);

      if (_firstOperand != null && _operator != null && !_shouldResetDisplay) {
        double? result = _calculate(_firstOperand!, currentValue, _operator!);
        if (result == null) {
          _display = 'Lỗi';
          _expression = '';
          _firstOperand = null;
          _operator = null;
          _shouldResetDisplay = true;
          return;
        } else {
          _firstOperand = result;
          _display = _formatResult(result);
          _expression = '${_formatResult(result)} $op';
        }
      } else {
        _firstOperand = currentValue;
        _expression = '${_formatResult(currentValue)} $op';
      }

      _operator = op;
      _shouldResetDisplay = true;
    });
  }

  void _onEqualsPressed() {
    setState(() {
      if (_display == 'Lỗi') return;

      if (_firstOperand == null || _operator == null) {
        return;
      }

      double secondOperand = _parseDisplay(_display);
      double? result = _calculate(_firstOperand!, secondOperand, _operator!);

      String expString = '${_formatResult(_firstOperand!)} $_operator ${_formatResult(secondOperand)} =';

      if (result == null) {
        _display = 'Lỗi';
        _expression = expString;
      } else {
        String resString = _formatResult(result);
        _expression = expString;
        _display = resString;
        _history.insert(0, HistoryItem(expression: expString, result: resString));
      }

      _firstOperand = null;
      _operator = null;
      _shouldResetDisplay = true;
    });
  }

  void _onPercentPressed() {
    setState(() {
      if (_display == 'Lỗi') return;
      double val = _parseDisplay(_display);
      double result;
      if (_firstOperand != null && _operator != null) {
        if (_operator == '+' || _operator == '-') {
          result = _firstOperand! * (val / 100.0);
        } else {
          result = val / 100.0;
        }
      } else {
        result = val / 100.0;
      }
      _display = _formatResult(result);
      _shouldResetDisplay = true;
    });
  }

  void _onSquarePressed() {
    setState(() {
      if (_display == 'Lỗi') return;
      double val = _parseDisplay(_display);
      double result = val * val;
      String expString = 'sqr(${_formatResult(val)})';
      String resString = _formatResult(result);
      _expression = '$expString =';
      _display = resString;
      _history.insert(0, HistoryItem(expression: '$expString =', result: resString));
      _shouldResetDisplay = true;
    });
  }

  void _onSqrtPressed() {
    setState(() {
      if (_display == 'Lỗi') return;
      double val = _parseDisplay(_display);
      if (val < 0) {
        _display = 'Lỗi';
        _expression = '√(${_formatResult(val)}) =';
        _shouldResetDisplay = true;
        return;
      }
      double result = math.sqrt(val);
      String expString = '√(${_formatResult(val)})';
      String resString = _formatResult(result);
      _expression = '$expString =';
      _display = resString;
      _history.insert(0, HistoryItem(expression: '$expString =', result: resString));
      _shouldResetDisplay = true;
    });
  }

  void _onReciprocalPressed() {
    setState(() {
      if (_display == 'Lỗi') return;
      double val = _parseDisplay(_display);
      if (val == 0) {
        _display = 'Lỗi';
        _expression = '1/(${_formatResult(val)}) =';
        _shouldResetDisplay = true;
        return;
      }
      double result = 1.0 / val;
      String expString = '1/(${_formatResult(val)})';
      String resString = _formatResult(result);
      _expression = '$expString =';
      _display = resString;
      _history.insert(0, HistoryItem(expression: '$expString =', result: resString));
      _shouldResetDisplay = true;
    });
  }

  // Memory Functions
  void _onMemoryAdd() {
    setState(() {
      if (_display == 'Lỗi') return;
      _memory += _parseDisplay(_display);
      _hasMemory = true;
      _shouldResetDisplay = true;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Đã cộng vào bộ nhớ (M = ${_formatResult(_memory)})'),
          duration: const Duration(seconds: 1),
        ),
      );
    });
  }

  void _onMemorySubtract() {
    setState(() {
      if (_display == 'Lỗi') return;
      _memory -= _parseDisplay(_display);
      _hasMemory = true;
      _shouldResetDisplay = true;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Đã trừ khỏi bộ nhớ (M = ${_formatResult(_memory)})'),
          duration: const Duration(seconds: 1),
        ),
      );
    });
  }

  void _onMemoryStore() {
    setState(() {
      if (_display == 'Lỗi') return;
      _memory = _parseDisplay(_display);
      _hasMemory = true;
      _shouldResetDisplay = true;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Đã lưu vào bộ nhớ (M = ${_formatResult(_memory)})'),
          duration: const Duration(seconds: 1),
        ),
      );
    });
  }

  void _onMemoryRecall() {
    setState(() {
      if (!_hasMemory) return;
      _display = _formatResult(_memory);
      _shouldResetDisplay = true;
    });
  }

  void _onMemoryClear() {
    setState(() {
      _memory = 0.0;
      _hasMemory = false;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Đã xóa bộ nhớ'),
          duration: Duration(seconds: 1),
        ),
      );
    });
  }

  void _showHistoryModal() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF2B2B2B),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: const EdgeInsets.all(20),
              height: 400,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Lịch sử tính toán',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      if (_history.isNotEmpty)
                        IconButton(
                          icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                          tooltip: 'Xóa lịch sử',
                          onPressed: () {
                            setState(() {
                              _history.clear();
                            });
                            setModalState(() {});
                          },
                        ),
                    ],
                  ),
                  const Divider(color: Colors.grey),
                  Expanded(
                    child: _history.isEmpty
                        ? const Center(
                            child: Text(
                              'Chưa có lịch sử tính toán nào',
                              style: TextStyle(color: Colors.grey, fontSize: 16),
                            ),
                          )
                        : ListView.builder(
                            itemCount: _history.length,
                            itemBuilder: (context, index) {
                              final item = _history[index];
                              return ListTile(
                                title: Text(
                                  item.expression,
                                  style: const TextStyle(
                                    color: Colors.grey,
                                    fontSize: 16,
                                  ),
                                  textAlign: TextAlign.right,
                                ),
                                subtitle: Text(
                                  item.result,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  textAlign: TextAlign.right,
                                ),
                                onTap: () {
                                  setState(() {
                                    _display = item.result;
                                    _shouldResetDisplay = true;
                                  });
                                  Navigator.pop(context);
                                },
                              );
                            },
                          ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  double _parseDisplay(String text) {
    String normalized = text.replaceAll(',', '.');
    return double.tryParse(normalized) ?? 0.0;
  }

  double? _calculate(double num1, double num2, String op) {
    switch (op) {
      case '+':
        return num1 + num2;
      case '-':
        return num1 - num2;
      case '×':
        return num1 * num2;
      case '÷':
        if (num2 == 0) return null;
        return num1 / num2;
      default:
        return num2;
    }
  }

  String _formatResult(double value) {
    if (value.isNaN || value.isInfinite) return 'Lỗi';

    if (value == value.roundToDouble() && value.abs() < 1e12) {
      return value.toInt().toString();
    }

    String res = value.toStringAsFixed(8);
    if (res.contains('.')) {
      res = res.replaceAll(RegExp(r'0+$'), '');
      res = res.replaceAll(RegExp(r'\.$'), '');
    }
    return res.replaceAll('.', ',');
  }

  Widget _buildButton({
    required Widget child,
    required VoidCallback onPressed,
    Color backgroundColor = const Color(0xFF2D2D2D),
    Color textColor = Colors.white,
    int flex = 1,
  }) {
    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.all(4.0),
        child: SizedBox(
          height: 64,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: backgroundColor,
              foregroundColor: textColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              elevation: 0,
              padding: EdgeInsets.zero,
            ),
            onPressed: onPressed,
            child: child,
          ),
        ),
      ),
    );
  }

  Widget _buildTextButton(
    String text,
    VoidCallback onPressed, {
    Color backgroundColor = const Color(0xFF2D2D2D),
    Color textColor = Colors.white,
    int flex = 1,
    double fontSize = 22,
    FontWeight fontWeight = FontWeight.normal,
  }) {
    return _buildButton(
      flex: flex,
      backgroundColor: backgroundColor,
      textColor: textColor,
      onPressed: onPressed,
      child: Text(
        text,
        style: TextStyle(
          fontSize: fontSize,
          fontWeight: fontWeight,
          color: textColor,
        ),
      ),
    );
  }

  Widget _buildMemoryButton(String text, VoidCallback onPressed) {
    return Expanded(
      child: TextButton(
        onPressed: onPressed,
        style: TextButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 8),
          minimumSize: Size.zero,
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        ),
        child: Text(
          text,
          style: TextStyle(
            color: (_hasMemory && (text == 'MR' || text == 'MC'))
                ? Colors.amber
                : Colors.white70,
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1E1E1E),
      body: SafeArea(
        child: Column(
          children: [
            // Top Bar: Student Name & History Icon
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    '2324801030067 - Nguyễn Hoàng Thiên',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.history, color: Colors.white70),
                    tooltip: 'Lịch sử tính toán',
                    onPressed: _showHistoryModal,
                  ),
                ],
              ),
            ),

            // Flexible Display Area
            Expanded(
              child: Container(
                width: double.infinity,
                alignment: Alignment.bottomRight,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 16,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    // Expression line above main result
                    if (_expression.isNotEmpty)
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        reverse: true,
                        child: Text(
                          _expression,
                          style: const TextStyle(
                            fontSize: 22,
                            color: Colors.grey,
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ),
                    const SizedBox(height: 8),
                    // Main display value
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      reverse: true,
                      child: Text(
                        _display,
                        style: const TextStyle(
                          fontSize: 60,
                          fontWeight: FontWeight.w300,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Memory Row: M+, M-, MS (plus MC/MR if memory stored)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  if (_hasMemory) _buildMemoryButton('MC', _onMemoryClear),
                  if (_hasMemory) _buildMemoryButton('MR', _onMemoryRecall),
                  _buildMemoryButton('M+', _onMemoryAdd),
                  _buildMemoryButton('M-', _onMemorySubtract),
                  _buildMemoryButton('MS', _onMemoryStore),
                ],
              ),
            ),

            // Keypad Grid Layout (6 rows x 4 columns)
            Padding(
              padding: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
              child: Column(
                children: [
                  // Row 1: [%] [CE] [C] [⌫]
                  Row(
                    children: [
                      _buildTextButton('%', _onPercentPressed),
                      _buildTextButton('CE', _onClearEntryPressed),
                      _buildTextButton('C', _onClearPressed),
                      _buildButton(
                        onPressed: _onBackspacePressed,
                        child: const Icon(
                          Icons.backspace_outlined,
                          size: 22,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),

                  // Row 2: [¹/x] [x²] [√x] [÷]
                  Row(
                    children: [
                      _buildTextButton('¹/x', _onReciprocalPressed),
                      _buildTextButton('x²', _onSquarePressed),
                      _buildTextButton('√x', _onSqrtPressed),
                      _buildTextButton('÷', () => _onOperatorPressed('÷'), fontSize: 26),
                    ],
                  ),

                  // Row 3: [7] [8] [9] [×]
                  Row(
                    children: [
                      _buildTextButton('7', () => _onDigitPressed('7'), fontWeight: FontWeight.bold),
                      _buildTextButton('8', () => _onDigitPressed('8'), fontWeight: FontWeight.bold),
                      _buildTextButton('9', () => _onDigitPressed('9'), fontWeight: FontWeight.bold),
                      _buildTextButton('×', () => _onOperatorPressed('×'), fontSize: 26),
                    ],
                  ),

                  // Row 4: [4] [5] [6] [-]
                  Row(
                    children: [
                      _buildTextButton('4', () => _onDigitPressed('4'), fontWeight: FontWeight.bold),
                      _buildTextButton('5', () => _onDigitPressed('5'), fontWeight: FontWeight.bold),
                      _buildTextButton('6', () => _onDigitPressed('6'), fontWeight: FontWeight.bold),
                      _buildTextButton('-', () => _onOperatorPressed('-'), fontSize: 28),
                    ],
                  ),

                  // Row 5: [1] [2] [3] [+]
                  Row(
                    children: [
                      _buildTextButton('1', () => _onDigitPressed('1'), fontWeight: FontWeight.bold),
                      _buildTextButton('2', () => _onDigitPressed('2'), fontWeight: FontWeight.bold),
                      _buildTextButton('3', () => _onDigitPressed('3'), fontWeight: FontWeight.bold),
                      _buildTextButton('+', () => _onOperatorPressed('+'), fontSize: 26),
                    ],
                  ),

                  // Row 6: [+/-] [0] [,] [=]
                  Row(
                    children: [
                      _buildTextButton('+/-', _onNegatePressed),
                      _buildTextButton('0', () => _onDigitPressed('0'), fontWeight: FontWeight.bold),
                      _buildTextButton(',', _onCommaPressed),
                      _buildTextButton(
                        '=',
                        _onEqualsPressed,
                        backgroundColor: const Color(0xFF50B4F8), // Accent Light Blue
                        textColor: Colors.black, // Black text on blue
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
