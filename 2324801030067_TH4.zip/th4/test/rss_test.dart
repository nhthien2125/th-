import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';

void main() {
  final feeds = {
    'Tin mới nhất': 'https://vnexpress.net/rss/tin-moi-nhat.rss',
    'Thời sự': 'https://vnexpress.net/rss/thoi-su.rss',
    'Thế giới': 'https://vnexpress.net/rss/the-gioi.rss',
    'Kinh doanh': 'https://vnexpress.net/rss/kinh-doanh.rss',
    'Giải trí': 'https://vnexpress.net/rss/giai-tri.rss',
    'Thể thao': 'https://vnexpress.net/rss/the-thao.rss',
    'Pháp luật': 'https://vnexpress.net/rss/phap-luat.rss',
    'Giáo dục': 'https://vnexpress.net/rss/giao-duc.rss',
    'Sức khỏe': 'https://vnexpress.net/rss/suc-khoe.rss',
    'Đời sống': 'https://vnexpress.net/rss/doi-song.rss',
    'Du lịch': 'https://vnexpress.net/rss/du-lich.rss',
    'Khoa học': 'https://vnexpress.net/rss/khoa-hoc.rss',
    'Số hóa': 'https://vnexpress.net/rss/so-hoa.rss',
    'Xe': 'https://vnexpress.net/rss/oto-xe-may.rss',
  };

  test('Check all VnExpress feeds parse correctly', () async {
    for (var entry in feeds.entries) {
      final response = await http.get(Uri.parse(entry.value));
      expect(response.statusCode, 200, reason: 'Failed for ${entry.key}');
      final document = XmlDocument.parse(response.body);
      final items = document.findAllElements('item');
      expect(items.isNotEmpty, true, reason: 'No items found for ${entry.key}');
      
      final first = items.first;
      final title = first.findElements('title').singleOrNull?.innerText ?? '';
      final description = first.findElements('description').singleOrNull?.innerText ?? '';
      
      final imgMatch = RegExp(r'src="([^"]+)"').firstMatch(description);
      final imgUrl = imgMatch?.group(1);
      
      final cleanDesc = description.replaceAll(RegExp(r'<[^>]*>'), '').trim();
      
      print('${entry.key}: count=${items.length}, title=$title, img=$imgUrl, descSnippet=${cleanDesc.length > 30 ? cleanDesc.substring(0, 30) : cleanDesc}');
    }
  });
}
