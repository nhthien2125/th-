import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:th4/main.dart';
import 'package:th4/services/settings_service.dart';

void main() {
  testWidgets('App renders correctly with Bottom Navigation Tabs', (WidgetTester tester) async {
    final settingsService = SettingsService();

    await tester.pumpWidget(MyApp(settingsService: settingsService));
    await tester.pump();

    // Verify main bottom navigation items exist
    expect(find.text('Tin tổng hợp'), findsOneWidget);
    expect(find.text('Chủ đề'), findsOneWidget);
    expect(find.text('Tin mới nhất'), findsOneWidget);
    expect(find.text('Cài đặt'), findsOneWidget);

    // Switch tab to Cài đặt
    await tester.tap(find.text('Cài đặt'));
    await tester.pumpAndSettle();

    // Verify Settings screen elements
    expect(find.text('CÀI ĐẶT'), findsOneWidget);
    expect(find.text('GIAO DIỆN'), findsOneWidget);
    expect(find.text('THÔNG TIN ỨNG DỤNG'), findsOneWidget);
  });
}
