import 'package:flutter_test/flutter_test.dart';
import 'package:th4/main.dart';
import 'package:th4/services/settings_service.dart';

void main() {
  testWidgets('App smoke test', (WidgetTester tester) async {
    final settingsService = SettingsService();
    await tester.pumpWidget(MyApp(settingsService: settingsService));
    await tester.pump();
    expect(find.text('ĐỌC BÁO ONLINE'), findsOneWidget);
  });
}
