import 'package:flutter/material.dart';

class NewsCategory {
  final String name;
  final String rssUrl;
  final IconData icon;

  const NewsCategory({
    required this.name,
    required this.rssUrl,
    required this.icon,
  });

  static const List<NewsCategory> categories = [
    NewsCategory(
      name: 'Thời sự',
      rssUrl: 'https://vnexpress.net/rss/thoi-su.rss',
      icon: Icons.newspaper_rounded,
    ),
    NewsCategory(
      name: 'Thế giới',
      rssUrl: 'https://vnexpress.net/rss/the-gioi.rss',
      icon: Icons.public_rounded,
    ),
    NewsCategory(
      name: 'Kinh doanh',
      rssUrl: 'https://vnexpress.net/rss/kinh-doanh.rss',
      icon: Icons.business_center_rounded,
    ),
    NewsCategory(
      name: 'Giải trí',
      rssUrl: 'https://vnexpress.net/rss/giai-tri.rss',
      icon: Icons.movie_filter_rounded,
    ),
    NewsCategory(
      name: 'Thể thao',
      rssUrl: 'https://vnexpress.net/rss/the-thao.rss',
      icon: Icons.sports_soccer_rounded,
    ),
    NewsCategory(
      name: 'Pháp luật',
      rssUrl: 'https://vnexpress.net/rss/phap-luat.rss',
      icon: Icons.gavel_rounded,
    ),
    NewsCategory(
      name: 'Giáo dục',
      rssUrl: 'https://vnexpress.net/rss/giao-duc.rss',
      icon: Icons.school_rounded,
    ),
    NewsCategory(
      name: 'Sức khỏe',
      rssUrl: 'https://vnexpress.net/rss/suc-khoe.rss',
      icon: Icons.health_and_safety_rounded,
    ),
    NewsCategory(
      name: 'Đời sống',
      rssUrl: 'https://vnexpress.net/rss/doi-song.rss',
      icon: Icons.family_restroom_rounded,
    ),
    NewsCategory(
      name: 'Du lịch',
      rssUrl: 'https://vnexpress.net/rss/du-lich.rss',
      icon: Icons.flight_takeoff_rounded,
    ),
    NewsCategory(
      name: 'Khoa học',
      rssUrl: 'https://vnexpress.net/rss/khoa-hoc.rss',
      icon: Icons.science_rounded,
    ),
    NewsCategory(
      name: 'Công nghệ',
      rssUrl: 'https://vnexpress.net/rss/so-hoa.rss',
      icon: Icons.devices_rounded,
    ),
    NewsCategory(
      name: 'Xe',
      rssUrl: 'https://vnexpress.net/rss/oto-xe-may.rss',
      icon: Icons.directions_car_rounded,
    ),
  ];
}
