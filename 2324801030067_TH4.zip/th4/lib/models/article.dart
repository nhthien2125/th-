import 'package:intl/intl.dart';

class Article {
  final String title;
  final String link;
  final String description;
  final String pubDate;
  final String? imageUrl;
  final String? category;

  Article({
    required this.title,
    required this.link,
    required this.description,
    required this.pubDate,
    this.imageUrl,
    this.category,
  });

  /// Formats pubDate string into a clean user-friendly date string like "21 Apr 2026"
  String get formattedDate {
    if (pubDate.isEmpty) return '';
    try {
      // Common RSS date format: "Mon, 28 Sep 2026 17:14:07 +0700"
      final cleanDateStr = pubDate.trim();
      // Parse using HttpDate or standard RegExp if needed
      // standard DateFormat for EEE, dd MMM yyyy HH:mm:ss Z
      DateTime? parsed;
      try {
        parsed = DateFormat('EEE, dd MMM yyyy HH:mm:ss Z', 'en_US').parse(cleanDateStr);
      } catch (_) {
        try {
          parsed = DateTime.parse(cleanDateStr);
        } catch (_) {}
      }

      if (parsed != null) {
        return DateFormat('dd MMM yyyy').format(parsed);
      }
    } catch (_) {}
    
    // Fallback if parsing fails, strip time zone if present
    return pubDate.split('+').first.trim();
  }
}
