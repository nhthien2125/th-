import 'package:flutter/material.dart';
import '../models/article.dart';
import '../models/category_model.dart';
import '../services/rss_service.dart';
import '../widgets/article_card.dart';
import 'article_detail_screen.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  NewsCategory _selectedCategory = NewsCategory.categories.first;
  late Future<List<Article>> _articlesFuture;

  @override
  void initState() {
    super.initState();
    _fetchCategoryArticles();
  }

  void _fetchCategoryArticles() {
    setState(() {
      _articlesFuture = RssService.fetchArticles(url: _selectedCategory.rssUrl);
    });
  }

  void _onCategorySelected(NewsCategory category) {
    if (_selectedCategory != category) {
      setState(() {
        _selectedCategory = category;
      });
      _fetchCategoryArticles();
    }
  }

  void _openArticleDetail(Article article) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ArticleDetailScreen(article: article),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Tin Theo Chủ Đề: ${_selectedCategory.name}',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            tooltip: 'Làm mới',
            onPressed: _fetchCategoryArticles,
          ),
        ],
      ),
      body: Column(
        children: [
          // Category Selection Horizontal Scroll List
          Container(
            height: 54,
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: isDark ? Colors.grey.shade900 : Colors.grey.shade100,
              border: Border(
                bottom: BorderSide(
                  color: isDark ? Colors.grey.shade800 : Colors.grey.shade300,
                  width: 0.8,
                ),
              ),
            ),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: NewsCategory.categories.length,
              itemBuilder: (context, index) {
                final category = NewsCategory.categories[index];
                final isSelected = _selectedCategory == category;

                return Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: FilterChip(
                    avatar: Icon(
                      category.icon,
                      size: 18,
                      color: isSelected
                          ? Colors.white
                          : (isDark ? Colors.grey.shade300 : Colors.grey.shade700),
                    ),
                    label: Text(category.name),
                    selected: isSelected,
                    selectedColor: theme.colorScheme.primary,
                    checkmarkColor: Colors.white,
                    labelStyle: TextStyle(
                      color: isSelected
                          ? Colors.white
                          : (isDark ? Colors.grey.shade200 : Colors.black87),
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      fontSize: 13,
                    ),
                    onSelected: (_) => _onCategorySelected(category),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    showCheckmark: false,
                  ),
                );
              },
            ),
          ),

          // Articles List
          Expanded(
            child: RefreshIndicator(
              onRefresh: () async {
                _fetchCategoryArticles();
                await _articlesFuture;
              },
              child: FutureBuilder<List<Article>>(
                future: _articlesFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const CircularProgressIndicator(),
                          const SizedBox(height: 16),
                          Text('Đang tải tin chủ đề "${_selectedCategory.name}"...'),
                        ],
                      ),
                    );
                  }

                  if (snapshot.hasError) {
                    return Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.error_outline_rounded,
                                size: 60, color: Colors.redAccent),
                            const SizedBox(height: 16),
                            Text(
                              'Không thể tải dữ liệu!\n${snapshot.error}',
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 14),
                            ),
                            const SizedBox(height: 16),
                            ElevatedButton.icon(
                              onPressed: _fetchCategoryArticles,
                              icon: const Icon(Icons.refresh),
                              label: const Text('Thử lại'),
                            ),
                          ],
                        ),
                      ),
                    );
                  }

                  final articles = snapshot.data ?? [];
                  if (articles.isEmpty) {
                    return Center(
                      child: Text('Không có bài viết nào trong chủ đề ${_selectedCategory.name}.'),
                    );
                  }

                  return ListView.builder(
                    physics: const AlwaysScrollableScrollPhysics(),
                    itemCount: articles.length,
                    itemBuilder: (context, index) {
                      final article = articles[index];
                      return ArticleCard(
                        article: article,
                        onTap: () => _openArticleDetail(article),
                      );
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
