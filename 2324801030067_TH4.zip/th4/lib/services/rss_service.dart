import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';
import '../models/article.dart';

class RssService {
  static const String mainFeedUrl = 'https://vnexpress.net/rss/tin-moi-nhat.rss';

  static Future<List<Article>> fetchArticles({String url = mainFeedUrl, int? limit}) async {
    try {
      final response = await http.get(Uri.parse(url)).timeout(
        const Duration(seconds: 15),
      );

      if (response.statusCode != 200) {
        throw Exception('Lỗi tải dữ liệu RSS: ${response.statusCode}');
      }

      // Handle potential encoding issue (VnExpress uses UTF-8)
      final body = utf8.decode(response.bodyBytes);
      final document = XmlDocument.parse(body);
      final items = document.findAllElements('item');

      List<Article> articles = [];

      for (var item in items) {
        final title = item.findElements('title').singleOrNull?.innerText ?? '';
        final link = item.findElements('link').singleOrNull?.innerText ?? '';
        final pubDate = item.findElements('pubDate').singleOrNull?.innerText ?? '';
        final descriptionRaw = item.findElements('description').singleOrNull?.innerText ?? '';

        // Extract thumbnail image URL from <description> tag
        String? imageUrl;
        final imgMatch = RegExp(r'src="([^"]+)"').firstMatch(descriptionRaw);
        if (imgMatch != null) {
          imageUrl = imgMatch.group(1);
        } else {
          // Fallback check for <enclosure> or <media:content>
          final enclosure = item.findElements('enclosure').singleOrNull;
          if (enclosure != null) {
            imageUrl = enclosure.getAttribute('url');
          }
        }

        final cleanDescription = _cleanHtml(descriptionRaw);

        articles.add(Article(
          title: title.trim(),
          link: link.trim(),
          description: cleanDescription,
          pubDate: pubDate.trim(),
          imageUrl: imageUrl,
        ));

        if (limit != null && articles.length >= limit) {
          break;
        }
      }

      return articles;
    } catch (e) {
      throw Exception('Không thể kết nối đến VnExpress RSS: $e');
    }
  }

  static String _cleanHtml(String htmlString) {
    if (htmlString.isEmpty) return '';
    
    // Remove HTML tags
    String text = htmlString.replaceAll(RegExp(r'<[^>]*>'), ' ');
    
    // Unescape common HTML entities
    text = text
        .replaceAll('&quot;', '"')
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&#39;', "'")
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&a&', '&');
        
    // Clean multiple spaces and newlines
    text = text.replaceAll(RegExp(r'\s+'), ' ').trim();
    return text;
  }
}
