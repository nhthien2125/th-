import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsService extends ChangeNotifier {
  static const String _keyDarkMode = 'is_dark_mode';
  static const String _keyStudentClass = 'student_class';
  static const String _keyStudentId = 'student_id';
  static const String _keyStudentName = 'student_name';

  SharedPreferences? _prefs;

  bool _isDarkMode = false;
  String _studentClass = '21DTH1A';
  String _studentId = '2180601234';
  String _studentName = 'Nguyễn Văn A';

  bool get isDarkMode => _isDarkMode;
  ThemeMode get themeMode => _isDarkMode ? ThemeMode.dark : ThemeMode.light;
  String get studentClass => _studentClass;
  String get studentId => _studentId;
  String get studentName => _studentName;

  SettingsService([SharedPreferences? prefs]) {
    if (prefs != null) {
      _prefs = prefs;
      _readFromPrefs(prefs);
    } else {
      _initPrefs();
    }
  }

  void _readFromPrefs(SharedPreferences prefs) {
    _isDarkMode = prefs.getBool(_keyDarkMode) ?? false;
    _studentClass = prefs.getString(_keyStudentClass) ?? 'KTPM01';
    _studentId = prefs.getString(_keyStudentId) ?? '2324801030067';
    _studentName = prefs.getString(_keyStudentName) ?? 'Nguyễn Hoàng Thiên';
  }

  Future<void> _initPrefs() async {
    try {
      _prefs = await SharedPreferences.getInstance();
      if (_prefs != null) {
        _readFromPrefs(_prefs!);
        notifyListeners();
      }
    } catch (_) {}
  }

  Future<void> toggleDarkMode(bool value) async {
    _isDarkMode = value;
    notifyListeners();
    try {
      _prefs ??= await SharedPreferences.getInstance();
      await _prefs?.setBool(_keyDarkMode, value);
    } catch (_) {}
  }

  Future<void> updateStudentInfo({
    required String className,
    required String id,
    required String name,
  }) async {
    _studentClass = className;
    _studentId = id;
    _studentName = name;
    notifyListeners();
    try {
      _prefs ??= await SharedPreferences.getInstance();
      await _prefs?.setString(_keyStudentClass, className);
      await _prefs?.setString(_keyStudentId, id);
      await _prefs?.setString(_keyStudentName, name);
    } catch (_) {}
  }
}
